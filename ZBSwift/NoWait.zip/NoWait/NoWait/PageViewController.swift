//
//  PageViewController.swift
//  NoWait
//
//  Created by ZBin on 15/10/5.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import UIKit

class PageViewController: UIPageViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    


}
