//
//  LookupViewController.swift
//  NoWait
//
//  Created by ZBin on 15/11/7.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import Cocoa

class LookupViewController: UIViewController {

}
