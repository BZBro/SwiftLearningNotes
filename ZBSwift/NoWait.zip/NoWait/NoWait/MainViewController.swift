//
//  MainViewController.swift
//  NoWait
//
//  Created by Admin on 15/9/27.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import UIKit
import CoreData
class MainViewController: UITabBarController {

   
}
