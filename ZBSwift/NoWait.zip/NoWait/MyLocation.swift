//
//  MyLocation.swift
//  NoWait
//
//  Created by ZBin on 15/10/4.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import Foundation
import CoreData

class MyLocation: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
