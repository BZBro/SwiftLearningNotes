//
//  Users.swift
//  NoWait
//
//  Created by Admin on 15/9/23.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import Foundation
import CoreData
@objc(Users)
class Users: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
