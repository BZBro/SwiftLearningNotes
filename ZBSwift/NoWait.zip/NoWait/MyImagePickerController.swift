//
//  MyImagePickerController.swift
//  NoWait
//
//  Created by ZBin on 15/10/13.
//  Copyright © 2015年 ZhangBin. All rights reserved.
//

import UIKit
import Foundation
class MyImagePickerController: UIImagePickerController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
