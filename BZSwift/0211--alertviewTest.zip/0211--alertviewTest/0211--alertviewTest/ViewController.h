//
//  ViewController.h
//  0211--alertviewTest
//
//  Created by ZBin on 16/2/11.
//  Copyright © 2016年 BZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

