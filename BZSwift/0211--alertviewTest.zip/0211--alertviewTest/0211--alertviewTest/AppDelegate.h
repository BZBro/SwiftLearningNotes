//
//  AppDelegate.h
//  0211--alertviewTest
//
//  Created by ZBin on 16/2/11.
//  Copyright © 2016年 BZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

