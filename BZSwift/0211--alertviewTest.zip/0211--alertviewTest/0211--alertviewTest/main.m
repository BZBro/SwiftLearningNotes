//
//  main.m
//  0211--alertviewTest
//
//  Created by ZBin on 16/2/11.
//  Copyright © 2016年 BZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
