//
//  WXOtherLoginViewController.h
//  WeiXin
//
//  Created by Yong Feng Guo on 14-11-19.
//  Copyright (c) 2014年 Fung. All rights reserved.
//

#import "WXBaseLoginViewController.h"

@interface WXOtherLoginViewController : WXBaseLoginViewController

@end
