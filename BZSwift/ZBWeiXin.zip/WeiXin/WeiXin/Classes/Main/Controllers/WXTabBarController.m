//
//  WXTabBarController.m
//  WeiXin
//
//  Created by Yong Feng Guo on 14-11-19.
//  Copyright (c) 2014年 Fung. All rights reserved.
//

#import "WXTabBarController.h"

@implementation WXTabBarController

@end
