//
//  UIScreen+WF.h
//  WeiXin
//
//  Created by Yong Feng Guo on 14-11-22.
//  Copyright (c) 2014年 Fung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScreen (WF)

@property(nonatomic,assign,readonly)CGFloat screenH;
@property(nonatomic,assign,readonly)CGFloat screenW;

@end
