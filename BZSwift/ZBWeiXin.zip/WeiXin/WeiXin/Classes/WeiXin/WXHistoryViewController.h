//
//  WXHistoryViewController.h
//  WeiXin
//
//  Created by Yong Feng Guo on 14-11-20.
//  Copyright (c) 2014年 Fung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXHistoryViewController : UITableViewController

@end
