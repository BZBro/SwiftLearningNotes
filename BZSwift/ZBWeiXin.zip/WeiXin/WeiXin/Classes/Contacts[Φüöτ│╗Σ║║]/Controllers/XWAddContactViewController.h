//
//  XWAddContactViewController.h
//  WeiXin
//
//  Created by Yong Feng Guo on 14-11-21.
//  Copyright (c) 2014年 Fung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWAddContactViewController : UITableViewController


@end
